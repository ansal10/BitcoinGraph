import requests
import time
from selenium import webdriver
import json

FILENAME = '/Users/ansal/PycharmProjects/PyScripts/data.txt'
GRAPH_SIZE_LIMIT = 100

def zebpay_price():
	url = "https://api.zebpay.com/api/v1/ticker?currencyCode=INR"
	res = requests.get(url).text
	res = json.loads(res)
	buy = res['buy']
	sell = res['sell']
	return buy, sell


def bitcoin_india_price():
	url = 'https://bitcoin-india.org'
	driver = webdriver.Chrome()
	try:
		driver.get(url)
		time.sleep(10)
		buy = float(driver.find_elements_by_id('buyvalue')[0].text)
		sell = float(driver.find_elements_by_id('sellvalue')[0].text)
	except Exception as e:
		print e
	finally:
		driver.close()
	return buy, sell


zb = zebpay_price()
bci = bitcoin_india_price()

file_data = open(FILENAME).read()
data = json.loads(file_data)
data['data']['zebpay']['buys'].append(zb[0])
data['data']['zebpay']['sells'].append(zb[1])

data['data']['bci']['buys'].append(bci[0])
data['data']['bci']['sells'].append(bci[1])

for wallet in ['zebpay', 'bci']:
	if data['data'][wallet]['buys'].__len__() > GRAPH_SIZE_LIMIT:
		data['data'][wallet]['buys'] = data['data'][wallet]['buys'][1:]
		data['data'][wallet]['sells'] = data['data'][wallet]['sells'][1:]

raw_data = json.dumps(data, indent=4)
f = open(FILENAME, 'w')
f.write(raw_data)
f.close()
